-- Vigie NC — schéma Supabase/PostGIS
-- À exécuter dans l'éditeur SQL Supabase (ou via `supabase db push`)

create extension if not exists postgis;

-- ---------------------------------------------------------------------
-- Types de signalement
-- ---------------------------------------------------------------------
create type report_type as enum (
  'trafic_dense',
  'accident',
  'route_coupee',
  'inondation',
  'chaussee_degradee',
  'autre'
);

-- ---------------------------------------------------------------------
-- Zones (points/segments suivis pour l'historique — ex: RT1 Col de Tonghoué)
-- ---------------------------------------------------------------------
create table zones (
  id text primary key,              -- slug, ex: 'col-de-tonghoue'
  name text not null,
  risk_label text,
  geom geography(point, 4326) not null,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- Signalements — anonymes, expiration automatique sauf confirmation
-- ---------------------------------------------------------------------
create table reports (
  id uuid primary key default gen_random_uuid(),
  type report_type not null,
  zone_id text references zones(id),
  geom geography(point, 4326) not null,
  photo_url text,
  confirmations int not null default 0,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '4 hours'),
  -- device_hash: identifiant anonyme côté client (ex: hash du localStorage),
  -- jamais un identifiant de compte — sert uniquement à empêcher qu'un même
  -- appareil confirme plusieurs fois son propre signalement.
  device_hash text
);

create index reports_geom_idx on reports using gist (geom);
create index reports_expires_at_idx on reports (expires_at);

-- ---------------------------------------------------------------------
-- Confirmations — chaque confirmation repousse l'expiration
-- ---------------------------------------------------------------------
create table report_confirmations (
  id uuid primary key default gen_random_uuid(),
  report_id uuid not null references reports(id) on delete cascade,
  device_hash text not null,
  created_at timestamptz not null default now(),
  unique (report_id, device_hash)
);

create or replace function extend_report_on_confirmation()
returns trigger as $$
begin
  update reports
  set
    confirmations = confirmations + 1,
    expires_at = greatest(expires_at, now() + interval '2 hours')
  where id = new.report_id;
  return new;
end;
$$ language plpgsql security definer;

create trigger trg_extend_report_on_confirmation
after insert on report_confirmations
for each row execute function extend_report_on_confirmation();

-- ---------------------------------------------------------------------
-- Vue agrégée pour l'écran Historique (compte par mois sur 12 mois glissants)
-- ---------------------------------------------------------------------
create view zone_history as
select
  z.id as zone_id,
  z.name as zone_name,
  z.risk_label,
  count(r.id) filter (where r.created_at > now() - interval '1 year') as incidents_this_year,
  array_agg(
    extract(month from r.created_at) order by r.created_at
  ) filter (where r.created_at > now() - interval '1 year') as incident_months
from zones z
left join reports r on r.zone_id = z.id
group by z.id, z.name, z.risk_label;

-- ---------------------------------------------------------------------
-- RLS — lecture publique (carte + historique publics par nature du projet),
-- écriture anonyme limitée à l'insertion de signalements et confirmations.
-- ---------------------------------------------------------------------
alter table zones enable row level security;
alter table reports enable row level security;
alter table report_confirmations enable row level security;

create policy "zones lecture publique"
  on zones for select
  using (true);

create policy "reports lecture publique"
  on reports for select
  using (true);

create policy "reports insertion anonyme"
  on reports for insert
  with check (true);

-- Pas d'update ni de delete anonyme sur reports : seule la fonction
-- extend_report_on_confirmation() (security definer) peut modifier
-- confirmations / expires_at.

create policy "confirmations insertion anonyme"
  on report_confirmations for insert
  with check (true);

create policy "confirmations lecture publique"
  on report_confirmations for select
  using (true);

-- ---------------------------------------------------------------------
-- Nettoyage : à brancher sur un cron Supabase (pg_cron) pour purger
-- les signalements expirés depuis plus de 24h.
-- ---------------------------------------------------------------------
-- select cron.schedule('purge-expired-reports', '0 * * * *', $$
--   delete from reports where expires_at < now() - interval '24 hours';
-- $$);
