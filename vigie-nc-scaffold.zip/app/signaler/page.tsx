"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { TopBarPlain } from "@/components/TopBar";
import { ReportTypeGrid } from "@/components/ReportTypeGrid";
import { ReportType } from "@/lib/types";
import { supabase, isSupabaseConfigured } from "@/lib/supabase";

export default function SignalerPage() {
  const router = useRouter();
  const [type, setType] = useState<ReportType | null>("route_coupee");
  const [photo, setPhoto] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit() {
    if (!type || submitting) return;
    setSubmitting(true);

    if (isSupabaseConfigured && supabase) {
      // Position réelle à récupérer via navigator.geolocation côté client
      // avant l'envoi — laissé en TODO pour brancher la géoloc utilisateur.
      await supabase.from("reports").insert({
        type,
        confirmations: 0,
        expires_at: new Date(Date.now() + 4 * 60 * 60_000).toISOString(),
      });
    }

    setSubmitting(false);
    router.push("/");
  }

  return (
    <>
      <TopBarPlain title="Signaler" backHref="/" />
      <ReportTypeGrid value={type} onChange={setType} />

      <label className="mx-3.5 mt-4 flex items-center justify-center gap-2 rounded-2xl border border-dashed border-white/[0.15] py-3.5 text-[12.5px] text-mist-dim cursor-pointer">
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth={1.5}
          className="w-[18px] h-[18px]"
        >
          <rect x="3" y="7" width="18" height="13" rx="2" />
          <path d="M8 7l1.5-3h5L16 7" />
          <circle cx="12" cy="13.5" r="3.3" />
        </svg>
        {photo ? photo.name : "Ajouter une photo (optionnel)"}
        <input
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={(e) => setPhoto(e.target.files?.[0] ?? null)}
        />
      </label>

      <button
        type="button"
        disabled={!type || submitting}
        onClick={handleSubmit}
        className="mx-3.5 mt-4 rounded-2xl py-3.5 font-display font-semibold text-[14px] text-void disabled:opacity-50"
        style={{ background: "linear-gradient(160deg, #E8622F, #C1440E)" }}
      >
        {submitting ? "Envoi…" : "Envoyer le signalement"}
      </button>

      <p className="mx-3.5 mt-3 text-center font-mono text-[10px] text-mist-dim opacity-70">
        Anonyme · visible immédiatement · expire dans 4h sauf confirmation
      </p>
    </>
  );
}
