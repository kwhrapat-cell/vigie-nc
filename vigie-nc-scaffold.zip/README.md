# Vigie NC

La route, le ciel et le terrain calédonien, réunis en direct — et une mémoire
de ce qui revient trop souvent.

Scaffold reconstruit directement à partir de la maquette de présentation
(3 écrans : carte en direct, signalement, historique de zone), fidèle aux
couleurs, polices et micro-interactions de la maquette.

## Stack

- Next.js 14 (App Router) + TypeScript
- Tailwind CSS — tokens de couleur repris tels quels de la maquette
  (`tailwind.config.ts`)
- Leaflet / react-leaflet — carte en direct, fond de carte sombre CARTO
- Supabase (Postgres + PostGIS) — signalements géolocalisés, RLS

## Démarrage

```bash
npm install
cp .env.example .env.local   # puis remplir avec les clés Supabase du projet
npm run dev
```

Sans `.env.local` rempli, l'app tourne quand même : les 3 écrans utilisent
les données de démonstration de `lib/mock-data.ts` (mêmes exemples que la
maquette : Dumbéa, Vallée du Tir, Rivière Sud, Col de Tonghoué).

## Base de données

Le schéma complet (tables, PostGIS, RLS, trigger de confirmation) est dans
`supabase/schema.sql`. À exécuter une fois dans l'éditeur SQL du dashboard
Supabase, ou via `supabase db push` si la CLI est installée.

Logique clé :
- un signalement est anonyme, expire par défaut après 4h ;
- chaque confirmation d'un autre appareil repousse l'expiration de 2h
  (voir `extend_report_on_confirmation()`) ;
- l'historique de zone (`zone_history`) agrège les signalements par zone
  sur 12 mois glissants pour alimenter le graphique de l'écran 3.

## Structure

```
app/
  page.tsx                    écran 1 — carte en direct
  signaler/page.tsx           écran 2 — formulaire de signalement
  historique/[zoneId]/page.tsx écran 3 — historique de zone
components/                   composants d'écran (carte, FAB, grille, etc.)
lib/                          types, client Supabase, données de démo
supabase/schema.sql           schéma complet + RLS
```

## À faire ensuite

- Brancher `navigator.geolocation` sur l'écran Signaler pour capter la
  position réelle avant l'insertion (actuellement en TODO dans
  `app/signaler/page.tsx`).
- Upload de la photo de signalement vers Supabase Storage (le champ
  `photo_url` existe déjà côté schéma).
- Peupler la table `zones` avec les axes/zones à risque suivis en priorité.
- Reprise avec Claude Code : ouvrir ce dossier comme projet et pointer
  vers ce README + `supabase/schema.sql` pour le contexte.
